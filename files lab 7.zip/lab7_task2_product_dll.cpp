#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* prev;
    Node* next;
};

int main()
{
    // Create initial nodes
    Node* n1 = new Node{101, NULL, NULL};
    Node* n2 = new Node{102, NULL, NULL};
    Node* n3 = new Node{103, NULL, NULL};
    Node* n4 = new Node{104, NULL, NULL};
    Node* n5 = new Node{105, NULL, NULL};

    // Link nodes
    n1->next = n2;
    n2->prev = n1;
    n2->next = n3;
    n3->prev = n2;
    n3->next = n4;
    n4->prev = n3;
    n4->next = n5;
    n5->prev = n4;

    Node* head = n1;

    // 1. Add product 100 at the start
    Node* newNode = new Node{100, NULL, head};
    head->prev = newNode;
    head = newNode;

    // 2. Add product 1035 after product 103
    Node* temp = head;

    while (temp != NULL && temp->data != 103)
    {
        temp = temp->next;
    }

    if (temp != NULL)
    {
        Node* newNode = new Node{1035, temp, temp->next};
        temp->next->prev = newNode;
        temp->next = newNode;
    }

    // 3. Add product 106 at the end
    temp = head;

    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    Node* endNode = new Node{106, temp, NULL};
    temp->next = endNode;

    // 4. Delete the first product
    temp = head;
    head = head->next;
    head->prev = NULL;
    delete temp;

    // 5. Delete product 104
    temp = head;

    while (temp != NULL && temp->data != 104)
    {
        temp = temp->next;
    }

    if (temp != NULL)
    {
        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;
        delete temp;
    }

    // 6. Delete the last product
    temp = head;

    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->prev->next = NULL;
    delete temp;

    // 7. Display final list
    cout << "Final Product IDs: ";

    temp = head;
    while (temp != NULL)
    {
        cout << temp->data;
        if (temp->next != NULL)
            cout << " <-> ";
        temp = temp->next;
    }

    cout << endl;

    return 0;
}
