#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* prev;
    Node* next;
};

int main()
{
    // Create initial nodes
    Node* n1 = new Node{10, NULL, NULL};
    Node* n2 = new Node{20, NULL, NULL};
    Node* n3 = new Node{30, NULL, NULL};
    Node* n4 = new Node{40, NULL, NULL};
    Node* n5 = new Node{50, NULL, NULL};

    // Link nodes
    n1->next = n2;
    n2->prev = n1;
    n2->next = n3;
    n3->prev = n2;
    n3->next = n4;
    n4->prev = n3;
    n4->next = n5;
    n5->prev = n4;

    Node* head = n1;

    // 1. Add 5 at the start
    Node* newNode = new Node{5, NULL, head};
    head->prev = newNode;
    head = newNode;

    // 2. Add 25 after 20
    Node* temp = head;

    while (temp != NULL && temp->data != 20)
    {
        temp = temp->next;
    }

    if (temp != NULL)
    {
        Node* newNode = new Node{25, temp, temp->next};
        temp->next->prev = newNode;
        temp->next = newNode;
    }

    // 3. Add 60 at the end
    temp = head;

    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    Node* endNode = new Node{60, temp, NULL};
    temp->next = endNode;

    // 4. Display final list
    cout << "Final Student Roll Numbers: ";

    temp = head;
    while (temp != NULL)
    {
        cout << temp->data;
        if (temp->next != NULL)
            cout << " <-> ";
        temp = temp->next;
    }

    cout << endl;

    return 0;
}
