#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
};
void display(Node* head)
{
    Node* temp = head;

    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}
void deleteAtEnd(Node*& head)
{
    if (head == NULL)
    {
        return;
    }
    // If only one node
    if (head->next == NULL)
    {
        delete head;
        head = NULL;
        return;
    }
    Node* temp = head;

    // Go to second last node
    while (temp->next->next != NULL)
    {
        temp = temp->next;
    }
    delete temp->next;
    temp->next = NULL;
}
void deleteAtPosition(Node*& head, int position)
{
    if (head == NULL)
    {
        return;
    }
    // If position is 1
    if (position == 1)
    {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* temp = head;

    // Move to node before the required node
    for (int i = 1; i < position - 1; i++)
    {
        temp = temp->next;
    }
    Node* deleteNode = temp->next;
    temp->next = deleteNode->next;

    delete deleteNode;
}
int main()
{
    // Creating list
    Node* head = new Node();
    Node* second = new Node();
    Node* third = new Node();
    Node* fourth = new Node();
    Node* fifth = new Node();

    head->data = 10;
    head->next = second;

    second->data = 20;
    second->next = third;

    third->data = 30;
    third->next = fourth;

    fourth->data = 40;
    fourth->next = fifth;

    fifth->data = 50;
    fifth->next = NULL;

    cout << "Original List: ";
    display(head);

    // Delete last node
    deleteAtEnd(head);

    cout << "After deleting last node: ";
    display(head);

    // Delete position 2
    deleteAtPosition(head, 2);

    cout << "After deleting position 2: ";
    display(head);

    return 0;
}
