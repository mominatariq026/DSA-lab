#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
};
void display(Node* head)
{
    Node* temp = head;
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}
void deleteByValue(Node*& head, int value)
{
    // Check first node
    if (head == NULL)
    {
        cout << "List is empty" << endl;
        return;
    }
    if (head->data == value)
    {
        Node* temp = head;
        head = head->next;
        delete temp;
        cout << "Value deleted" << endl;
        return;
    }
    // Find the value
    Node* temp = head;
    while (temp->next != NULL)
    {
        if (temp->next->data == value)
        {
            Node* deleteNode = temp->next;

            temp->next = deleteNode->next;

            delete deleteNode;

            cout << "Value deleted" << endl;
            return;
        }
        temp = temp->next;
    }

    // Value not found
    cout << "Value not found" << endl;
}

int main()
{
    // Creating list
    Node* head = new Node();
    Node* second = new Node();
    Node* third = new Node();
    Node* fourth = new Node();

    head->data = 10;
    head->next = second;

    second->data = 20;
    second->next = third;

    third->data = 30;
    third->next = fourth;

    fourth->data = 40;
    fourth->next = NULL;

    cout << "Original List: ";
    display(head);

    // Delete first value
    cout << "\nDeleting 10:" << endl;
    deleteByValue(head, 10);
    display(head);

    // Delete middle value
    cout << "\nDeleting 30:" << endl;
    deleteByValue(head, 30);
    display(head);

    // Delete value that does not exist
    cout << "\nDeleting 100:" << endl;
    deleteByValue(head, 100);
    display(head);

    return 0;
}
