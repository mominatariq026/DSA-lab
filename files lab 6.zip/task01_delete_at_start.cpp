#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node* next;
};

void display(Node* head)
{
    Node* temp = head;

    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

void deleteAtStart(Node*& head)
{
    if (head == NULL)
    {
        cout << "List is empty" << endl;
        return;
    }

    Node* temp = head;
    head = head->next;
    delete temp;
}
int main()
{
    // Creating nodes
    Node* head = new Node();
    Node* second = new Node();
    Node* third = new Node();
    Node* fourth = new Node();

    head->data = 10;
    head->next = second;

    second->data = 20;
    second->next = third;

    third->data = 30;
    third->next = fourth;

    fourth->data = 40;
    fourth->next = NULL;

    cout << "Original List: ";
    display(head);

    // Delete first node
    deleteAtStart(head);

    cout << "After first deletion: ";
    display(head);

    // Delete first node again
    deleteAtStart(head);

    cout << "After second deletion: ";
    display(head);

    return 0;
}
