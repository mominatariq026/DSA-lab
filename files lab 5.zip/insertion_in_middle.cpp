#include <iostream>
using namespace std;
struct Node
{
  int data;
  Node* next;
};
int main()
{
  Node* head = new Node;
  Node* second = new Node;
  Node* third = new Node;
  Node* fourth = new Node;

  head->data = 10;
  second->data = 20;
  third->data = 30;
  fourth->data = 40;

  head->next = second;
  second->next = third;
  third->next = fourth;
  fourth->next = nullptr;

  cout << "Original Linked List: ";
  Node* temp = head;
  while (temp != nullptr)
  {
    cout << temp->data << " ";
    temp = temp->next;
  }
  int afterValue, newValue;
  cout << "\n\nEnter value after which you want to insert: ";
  cin >> afterValue;
  cout << "Enter new value: ";
  cin >> newValue;

  Node* newNode = new Node;
  newNode->data = newValue;
  temp = head;
  while (temp != nullptr && temp->data != afterValue)
  { temp = temp->next;
  }
  if (temp == nullptr)
  { cout << "\nValue not found in the list."; }
  else
  {
    newNode->next = temp->next;
    temp->next = newNode;
    cout << "\nLinked List after insertion: ";
    temp = head;
    while (temp != nullptr)
    {
      cout << temp->data << " ";
      temp = temp->next;
    }
  }
  return 0;
}
