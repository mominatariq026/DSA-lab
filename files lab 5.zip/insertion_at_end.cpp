#include <iostream>
using namespace std;
struct Node
{
  int data;
  Node* next;
};
int main()
{
  Node* head = new Node;
  Node* second = new Node;
  Node* third = new Node;

  head->data = 10;
  second->data = 20;
  third->data = 30;

  head->next = second;
  second->next = third;
  third->next = nullptr;

  cout << "Original Linked List: ";
  Node* temp = head;
  while (temp != nullptr)
  {
    cout << temp->data << " ";
    temp = temp->next;
  }
  // Create the new node
  Node* newNode = new Node;
  cout << "\nEnter value to insert at end: ";
  cin >> newNode->data;
  newNode->next = nullptr;

  temp = head;
  while (temp->next != nullptr)
  { temp = temp->next;
  }
  // Attach it
  temp->next = newNode;

  cout << "\nLinked List after insertion: ";
  temp = head;
  while (temp != nullptr)
  {cout << temp->data << " ";
    temp = temp->next;
  }
  return 0;
}
