#include <iostream>
using namespace std;

struct Node
{
  int data;
  Node* next;
};

int main()
{
  Node* head = new Node;
  Node* second = new Node;
  Node* third = new Node;

  // Assigning values
  head->data = 10;
  second->data = 20;
  third->data = 30;

  // Connect the nodes
  head->next = second;
  second->next = third;
  third->next = nullptr;

  cout << "Original Linked List: ";
  // Use temp variable
  Node* temp = head;
  while (temp != nullptr)
  {
    cout << temp->data << " ";
    temp = temp->next;
  }

  // Insertion Create the new node but not yet connected
  Node* newNode = new Node;
  cout << "\nEnter value to insert at beginning: ";
  cin >> newNode->data;

  // Two pointer changes
  newNode->next = head; // newnode point to the current first node
  head = newNode; // It updates head so that it points to the new node.
  cout << "Linked List after insertion: ";
  temp = head; // reset temp updated head
  while (temp != nullptr)
  {
    cout << temp->data << " ";
    temp = temp->next;
  }
  return 0;
}
