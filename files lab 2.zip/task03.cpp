#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;
};

int main()
{
    // Create three nodes
    Node* n1 = new Node;
    Node* n2 = new Node;
    Node* n3 = new Node;

    // Store values
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;

    // Link the nodes
    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    // Traverse and display values
    Node* temp = n1;

    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    return 0;
}
