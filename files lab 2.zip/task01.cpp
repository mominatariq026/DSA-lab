#include <iostream>
using namespace std;

int main()
{
    int a, b, c;

    int *p1 = &a;
    int *p2 = &b;
    int *p3 = &c;

    cout << "Enter three numbers: ";
    cin >> a >> b >> c;

    int maximum = *p1;

    if (*p2 > maximum)
        maximum = *p2;

    if (*p3 > maximum)
        maximum = *p3;

    cout << "Maximum value = " << maximum;

    return 0;
}
