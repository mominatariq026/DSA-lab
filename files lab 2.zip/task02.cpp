#include <iostream>
using namespace std;

int main()
{
    int arr[5];
    int *p = arr;

    cout << "Enter 5 elements: ";
    for (int i = 0; i < 5; i++)
    {
        cin >> *(p + i);
    }

    // Reverse the array using pointers
    for (int i = 0; i < 2; i++)
    {
        int temp = *(p + i);
        *(p + i) = *(p + (4 - i));
        *(p + (4 - i)) = temp;
    }

    cout << "Reversed array: ";
    for (int i = 0; i < 5; i++)
    {
        cout << *(p + i) << " ";
    }

    return 0;
}
